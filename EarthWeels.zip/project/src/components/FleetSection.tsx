import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const vehicles = [
  {
    id: 1,
    name: "Citadine Confort",
    description: "Notre berline standard offrant un excellent rapport qualité-prix avec tout le confort nécessaire pour vos trajets quotidiens.",
    features: ["4 passagers", "Climatisation", "Sièges confortables", "Espace bagages"],
    image: "https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    id: 2,
    name: "Familiale Plus",
    description: "Véhicule spacieux idéal pour les familles ou les petits groupes, avec un grand espace pour les bagages.",
    features: ["6 passagers", "Grand coffre", "Climatisation bi-zone", "Sièges rabattables"],
    image: "https://images.pexels.com/photos/112460/pexels-photo-112460.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    id: 3,
    name: "Berline Business",
    description: "Une berline élégante et confortable, parfaite pour vos déplacements professionnels en ville.",
    features: ["4 passagers", "Intérieur raffiné", "Wifi embarqué", "Port de charge USB"],
    image: "https://images.pexels.com/photos/707046/pexels-photo-707046.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    id: 4,
    name: "Navette Groupe",
    description: "Idéale pour les groupes ou les transferts vers l'aéroport, avec beaucoup d'espace pour les passagers et les bagages.",
    features: ["8 passagers", "Grand espace bagages", "Climatisation", "Configuration flexible"],
    image: "https://images.pexels.com/photos/2767807/pexels-photo-2767807.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  }
];

const FleetSection = () => {
  const [activeVehicle, setActiveVehicle] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);

  const nextVehicle = () => {
    setActiveVehicle((prev) => (prev === vehicles.length - 1 ? 0 : prev + 1));
  };

  const prevVehicle = () => {
    setActiveVehicle((prev) => (prev === 0 ? vehicles.length - 1 : prev - 1));
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('opacity-100');
            entry.target.classList.remove('opacity-0', 'translate-y-10');
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section
      id="fleet"
      ref={sectionRef}
      className="py-20 bg-gray-50 transition-all duration-1000 opacity-0 translate-y-10"
    >
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Notre Flotte</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Des véhicules confortables et bien entretenus pour tous vos besoins de déplacement en ville.
          </p>
        </div>

        <div className="relative max-w-6xl mx-auto">
          <button
            onClick={prevVehicle}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white rounded-full p-2 shadow-lg hover:bg-gray-100 transition-all duration-200 md:-left-6"
            aria-label="Véhicule précédent"
          >
            <ChevronLeft className="h-6 w-6 text-gray-800" />
          </button>
          
          <button
            onClick={nextVehicle}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white rounded-full p-2 shadow-lg hover:bg-gray-100 transition-all duration-200 md:-right-6"
            aria-label="Véhicule suivant"
          >
            <ChevronRight className="h-6 w-6 text-gray-800" />
          </button>

          <div className="overflow-hidden rounded-2xl shadow-xl">
            <div 
              className="flex transition-transform duration-500 ease-in-out" 
              style={{ transform: `translateX(-${activeVehicle * 100}%)` }}
            >
              {vehicles.map((vehicle) => (
                <div key={vehicle.id} className="w-full flex-shrink-0">
                  <div className="grid grid-cols-1 md:grid-cols-2">
                    <div 
                      className="h-64 md:h-auto bg-cover bg-center"
                      style={{ backgroundImage: `url(${vehicle.image})` }}
                    ></div>
                    <div className="bg-white p-8 md:p-12 flex flex-col justify-center">
                      <h3 className="text-2xl font-bold mb-4">{vehicle.name}</h3>
                      <p className="text-gray-600 mb-6">{vehicle.description}</p>
                      <ul className="space-y-2 mb-6">
                        {vehicle.features.map((feature, index) => (
                          <li key={index} className="flex items-center">
                            <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                      <button className="self-start bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-full px-6 py-2.5 transition-all duration-200 inline-flex items-center">
                        Réserver ce véhicule
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-center mt-8 space-x-2">
            {vehicles.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveVehicle(index)}
                className={`w-3 h-3 rounded-full transition-all duration-200 ${
                  activeVehicle === index ? 'bg-blue-600 w-6' : 'bg-gray-300'
                }`}
                aria-label={`Aller au véhicule ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default FleetSection;