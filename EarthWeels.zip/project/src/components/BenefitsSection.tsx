import React, { useRef, useEffect } from 'react';
import { Shield, Clock, Users, MapPin, Star, HeadphonesIcon, CreditCard, PhoneCall } from 'lucide-react';

const benefits = [
  {
    icon: <Shield size={36} className="text-blue-600" />,
    title: "Sécurité",
    description: "Chauffeurs professionnels vérifiés et système de suivi en temps réel pour votre tranquillité."
  },
  {
    icon: <Clock size={36} className="text-blue-600" />,
    title: "Ponctualité",
    description: "Service fiable avec suivi en temps réel pour respecter vos horaires."
  },
  {
    icon: <Users size={36} className="text-blue-600" />,
    title: "Service Client",
    description: "Des chauffeurs formés pour vous offrir une expérience agréable et professionnelle."
  },
  {
    icon: <MapPin size={36} className="text-blue-600" />,
    title: "Couverture",
    description: "Service disponible dans toute la ville et ses environs, 24h/24 et 7j/7."
  },
  {
    icon: <Star size={36} className="text-blue-600" />,
    title: "Confort",
    description: "Véhicules propres et bien entretenus avec climatisation pour votre confort."
  },
  {
    icon: <HeadphonesIcon size={36} className="text-blue-600" />,
    title: "Support 24/7",
    description: "Une équipe à votre écoute jour et nuit pour vous assister en cas de besoin."
  },
  {
    icon: <CreditCard size={36} className="text-blue-600" />,
    title: "Paiement Simple",
    description: "Paiement sécurisé par carte ou en espèces, avec reçu automatique par email."
  },
  {
    icon: <PhoneCall size={36} className="text-blue-600" />,
    title: "Réservation Facile",
    description: "Réservez en quelques clics via l'application ou par téléphone."
  }
];

const BenefitsSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const benefitRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );

    benefitRefs.current.forEach((benefit) => {
      if (benefit) observer.observe(benefit);
    });

    return () => {
      benefitRefs.current.forEach((benefit) => {
        if (benefit) observer.unobserve(benefit);
      });
    };
  }, []);

  return (
    <section
      id="benefits"
      ref={sectionRef}
      className="py-20 bg-white"
    >
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Pourquoi Choisir EarthWeels</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Nous innovons pour vous offrir une expérience de transport urbain simple, sûre et accessible.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              ref={(el) => (benefitRefs.current[index] = el)}
              className="p-6 rounded-lg border border-gray-100 bg-gray-50 hover:shadow-lg transition-all duration-300 opacity-0 transform translate-y-8"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="mb-4">{benefit.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
              <p className="text-gray-600">{benefit.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-20 bg-gradient-to-r from-blue-600 to-blue-400 rounded-2xl overflow-hidden shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-8 md:p-12 text-white">
              <h3 className="text-2xl md:text-3xl font-bold mb-4">L'Expérience EarthWeels</h3>
              <p className="text-lg opacity-90 mb-6">
                Rejoignez des milliers de clients satisfaits qui ont choisi une façon plus intelligente de se déplacer en ville.
              </p>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="flex-shrink-0 w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-4">
                    <Shield size={20} className="text-white" />
                  </div>
                  <p className="font-medium">Trajets assurés et sécurisés</p>
                </div>
                <div className="flex items-center">
                  <div className="flex-shrink-0 w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-4">
                    <Clock size={20} className="text-white" />
                  </div>
                  <p className="font-medium">Service disponible 24h/24</p>
                </div>
                <div className="flex items-center">
                  <div className="flex-shrink-0 w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-4">
                    <Star size={20} className="text-white" />
                  </div>
                  <p className="font-medium">Programme de fidélité avantageux</p>
                </div>
              </div>
            </div>
            <div className="bg-cover bg-center lg:h-auto" style={{ backgroundImage: "url(https://images.pexels.com/photos/3799122/pexels-photo-3799122.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)" }}></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;