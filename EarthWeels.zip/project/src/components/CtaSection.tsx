import React, { useRef, useEffect } from 'react';
import Button from './ui/Button';

const CtaSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('opacity-100', 'translate-y-0');
            entry.target.classList.remove('opacity-0', 'translate-y-10');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section className="py-20 bg-gradient-to-r from-green-500 to-blue-500">
      <div 
        ref={sectionRef} 
        className="container mx-auto px-4 text-center transition-all duration-1000 opacity-0 translate-y-10"
      >
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
          Ready to ride? Book your next trip with EarthWeels.
        </h2>
        <p className="text-xl text-white text-opacity-90 max-w-3xl mx-auto mb-10">
          Join thousands of satisfied customers who have switched to a smarter, more sustainable way to move around the city.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button 
            variant="primary" 
            size="lg" 
            className="bg-white text-green-500 hover:bg-gray-100 hover:text-green-600"
          >
            Book a Ride Now
          </Button>
          <Button 
            variant="outline" 
            size="lg" 
            className="border-white text-white hover:bg-white hover:bg-opacity-10"
          >
            Learn More
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;