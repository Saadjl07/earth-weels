import React from 'react';
import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-2xl font-bold mb-6">
              Earth<span className="text-green-400">Weels</span>
            </h3>
            <p className="text-gray-400 mb-6">
              Redefining urban mobility with style, speed, and sustainability. Experience a premium, tech-driven ride service for modern commuters.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-green-500 transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-green-500 transition-colors">
                <Twitter size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-green-500 transition-colors">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-green-500 transition-colors">
                <Linkedin size={18} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition-colors">Home</a></li>
              <li><a href="#how-it-works" className="text-gray-400 hover:text-green-400 transition-colors">How It Works</a></li>
              <li><a href="#fleet" className="text-gray-400 hover:text-green-400 transition-colors">Our Fleet</a></li>
              <li><a href="#benefits" className="text-gray-400 hover:text-green-400 transition-colors">Why EarthWeels</a></li>
              <li><a href="#app" className="text-gray-400 hover:text-green-400 transition-colors">Mobile App</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition-colors">Corporate Accounts</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Help & Support</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition-colors">Contact Us</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition-colors">FAQs</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition-colors">Terms of Service</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition-colors">Careers</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition-colors">Press</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Contact Information</h4>
            <ul className="space-y-4">
              <li className="flex">
                <MapPin className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" />
                <span className="text-gray-400">Rue Abou inan El marini<br />El Jadida, Maroc 24000</span>
              </li>
              <li className="flex">
                <Phone className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" />
                <span className="text-gray-400">+212 6 91 52 26 31</span>
              </li>
              <li className="flex">
                <Mail className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" />
                <span className="text-gray-400">info@earthweels.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 mt-8 border-t border-gray-800 text-center md:flex md:justify-between md:items-center">
          <div className="flex items-center justify-center mb-4 md:mb-0">
            <a href="#" className="inline-flex items-center justify-center bg-black text-white rounded-lg px-4 py-2 mr-4">
              <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18.71 19.5C17.88 20.74 17 21.95 15.66 21.97C14.32 22 13.89 21.18 12.37 21.18C10.84 21.18 10.37 21.95 9.09998 22C7.78998 22.05 6.79998 20.68 5.95998 19.47C4.24998 17 2.93998 12.45 4.69998 9.39C5.56998 7.87 7.12998 6.91 8.81998 6.88C10.1 6.86 11.32 7.75 12.11 7.75C12.89 7.75 14.37 6.68 15.92 6.84C16.57 6.87 18.39 7.1 19.56 8.82C19.47 8.88 17.39 10.1 17.41 12.63C17.44 15.65 20.06 16.66 20.09 16.67C20.06 16.74 19.67 18.11 18.71 19.5ZM13 3.5C13.73 2.67 14.94 2.04 15.94 2C16.07 3.17 15.6 4.35 14.9 5.19C14.21 6.04 13.09 6.7 11.95 6.61C11.8 5.46 12.36 4.26 13 3.5Z" fill="currentColor"/>
              </svg>
              <span className="text-sm">App Store</span>
            </a>
            <a href="#" className="inline-flex items-center justify-center bg-black text-white rounded-lg px-4 py-2">
              <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 20.5V3.5C3 2.91 3.34 2.39 3.84 2.15L13.69 12L3.84 21.85C3.34 21.6 3 21.09 3 20.5ZM16.81 15.12L6.05 21.34L14.54 12.85L16.81 15.12ZM20.16 10.81C20.5 11.08 20.75 11.5 20.75 12C20.75 12.5 20.53 12.9 20.18 13.18L17.89 14.5L15.39 12L17.89 9.5L20.16 10.81ZM6.05 2.66L16.81 8.88L14.54 11.15L6.05 2.66Z" fill="currentColor"/>
              </svg>
              <span className="text-sm">Google Play</span>
            </a>
          </div>
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} EarthWeels. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;