import React, { useState, useEffect } from 'react';
import { Menu, X, ChevronDown } from 'lucide-react';
import Button from './ui/Button';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
        <div className="flex items-center">
          <span className="text-2xl font-bold tracking-tighter mr-2">
            Earth<span className="text-blue-600">Weels</span>
          </span>
        </div>

        <nav className="hidden md:flex items-center space-x-10">
          <a href="#how-it-works" className="font-medium text-gray-800 hover:text-blue-600 transition-colors">
            Comment ça marche
          </a>
          <a href="#fleet" className="font-medium text-gray-800 hover:text-blue-600 transition-colors">
            Nos Véhicules
          </a>
          <a href="#benefits" className="font-medium text-gray-800 hover:text-blue-600 transition-colors">
            Pourquoi EarthWeels
          </a>
          <div className="relative group">
            <button className="flex items-center font-medium text-gray-800 hover:text-blue-600 transition-colors">
              Plus <ChevronDown className="ml-1 h-4 w-4" />
            </button>
            <div className="absolute left-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 transform origin-top-right">
              <div className="py-1">
                <a href="#testimonials" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Témoignages</a>
                <a href="#app" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Application Mobile</a>
                <a href="#contact" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Contact</a>
              </div>
            </div>
          </div>
        </nav>

        <div className="hidden md:block">
          <Button variant="primary">Réserver un trajet</Button>
        </div>

        <button 
          className="md:hidden text-gray-800"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {isMenuOpen && (
        <div className="md:hidden bg-white absolute top-full left-0 w-full shadow-md">
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <a 
              href="#how-it-works" 
              className="font-medium text-gray-800 py-2 border-b border-gray-100"
              onClick={() => setIsMenuOpen(false)}
            >
              Comment ça marche
            </a>
            <a 
              href="#fleet" 
              className="font-medium text-gray-800 py-2 border-b border-gray-100"
              onClick={() => setIsMenuOpen(false)}
            >
              Nos Véhicules
            </a>
            <a 
              href="#benefits" 
              className="font-medium text-gray-800 py-2 border-b border-gray-100"
              onClick={() => setIsMenuOpen(false)}
            >
              Pourquoi EarthWeels
            </a>
            <a 
              href="#testimonials" 
              className="font-medium text-gray-800 py-2 border-b border-gray-100"
              onClick={() => setIsMenuOpen(false)}
            >
              Témoignages
            </a>
            <a 
              href="#app" 
              className="font-medium text-gray-800 py-2 border-b border-gray-100"
              onClick={() => setIsMenuOpen(false)}
            >
              Application Mobile
            </a>
            <a 
              href="#contact" 
              className="font-medium text-gray-800 py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Contact
            </a>
            <Button variant="primary" className="mt-2">Réserver un trajet</Button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;