import React, { useEffect, useRef } from 'react';
import { Smartphone, MapPin, Car } from 'lucide-react';

const steps = [
  {
    icon: <Smartphone className="w-12 h-12 text-blue-600" />,
    title: "Réservez votre course",
    description: "Choisissez votre point de départ et d'arrivée via notre application ou site web.",
    delay: 100
  },
  {
    icon: <MapPin className="w-12 h-12 text-blue-600" />,
    title: "Suivez en temps réel",
    description: "Visualisez l'approche de votre chauffeur sur la carte avec une estimation précise.",
    delay: 300
  },
  {
    icon: <Car className="w-12 h-12 text-blue-600" />,
    title: "Profitez du trajet",
    description: "Voyagez confortablement avec nos chauffeurs professionnels et nos véhicules entretenus.",
    delay: 500
  }
];

const HowItWorks = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const stepRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );

    stepRefs.current.forEach((step) => {
      if (step) observer.observe(step);
    });

    return () => {
      stepRefs.current.forEach((step) => {
        if (step) observer.unobserve(step);
      });
    };
  }, []);

  return (
    <section 
      id="how-it-works" 
      ref={sectionRef}
      className="py-20 bg-white"
    >
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Comment ça marche</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Une mobilité simple en quelques clics. Notre processus est conçu pour vous mettre en route rapidement et efficacement.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div
              key={index}
              ref={(el) => (stepRefs.current[index] = el)}
              className="bg-gray-50 rounded-xl p-8 text-center transition-all duration-500 opacity-0 transform translate-y-8 hover:shadow-lg hover:-translate-y-1"
              style={{ animationDelay: `${step.delay}ms` }}
            >
              <div className="flex justify-center mb-6">
                {step.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
              <div className="mt-6 flex justify-center">
                <span className="rounded-full bg-blue-100 text-blue-800 font-medium text-sm px-3 py-1">
                  Étape {index + 1}
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="relative mt-20 max-w-4xl mx-auto">
          <div className="bg-gray-50 rounded-2xl p-8 md:p-12 shadow-lg">
            <h3 className="text-2xl font-bold mb-4">Prêt à essayer une nouvelle façon de vous déplacer ?</h3>
            <p className="text-gray-600 mb-6">
              Téléchargez notre application ou réservez directement depuis notre site web pour commencer à voyager plus intelligemment.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href="#download" 
                className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-full px-6 py-3 transition-all duration-200 text-center"
              >
                Télécharger l'application
              </a>
              <a 
                href="#" 
                className="inline-block bg-white border-2 border-blue-600 text-blue-600 hover:bg-blue-50 font-medium rounded-full px-6 py-3 transition-all duration-200 text-center"
              >
                Réserver sur le web
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;