import React, { useRef, useEffect } from 'react';
import { Smartphone, Download } from 'lucide-react';

const AppPromotion = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const phoneRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            if (phoneRef.current) {
              phoneRef.current.classList.add('opacity-100', 'translate-x-0');
              phoneRef.current.classList.remove('opacity-0', 'translate-x-20');
            }
            if (contentRef.current) {
              contentRef.current.classList.add('opacity-100', 'translate-x-0');
              contentRef.current.classList.remove('opacity-0', '-translate-x-20');
            }
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section
      id="app"
      ref={sectionRef}
      className="py-20 bg-white overflow-hidden"
    >
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div 
            ref={contentRef}
            className="transition-all duration-1000 opacity-0 -translate-x-20"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Get the EarthWeels App</h2>
            <p className="text-xl text-gray-600 mb-8">
              Get the full EarthWeels experience right at your fingertips. Our intuitive app puts premium urban mobility just a tap away.
            </p>
            <div className="space-y-4 mb-10">
              <div className="flex items-start">
                <div className="bg-green-100 p-2 rounded-full mr-4 mt-1">
                  <Smartphone size={20} className="text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-1">Real-time tracking</h3>
                  <p className="text-gray-600">Follow your driver's location and ETA in real-time.</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-green-100 p-2 rounded-full mr-4 mt-1">
                  <Download size={20} className="text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-1">Exclusive app benefits</h3>
                  <p className="text-gray-600">Special offers, quick booking, and simplified payments.</p>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <a 
                href="#" 
                className="inline-flex items-center justify-center bg-black text-white rounded-xl px-6 py-3 hover:bg-gray-800 transition-colors"
              >
                <svg className="w-6 h-6 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18.71 19.5C17.88 20.74 17 21.95 15.66 21.97C14.32 22 13.89 21.18 12.37 21.18C10.84 21.18 10.37 21.95 9.09998 22C7.78998 22.05 6.79998 20.68 5.95998 19.47C4.24998 17 2.93998 12.45 4.69998 9.39C5.56998 7.87 7.12998 6.91 8.81998 6.88C10.1 6.86 11.32 7.75 12.11 7.75C12.89 7.75 14.37 6.68 15.92 6.84C16.57 6.87 18.39 7.1 19.56 8.82C19.47 8.88 17.39 10.1 17.41 12.63C17.44 15.65 20.06 16.66 20.09 16.67C20.06 16.74 19.67 18.11 18.71 19.5ZM13 3.5C13.73 2.67 14.94 2.04 15.94 2C16.07 3.17 15.6 4.35 14.9 5.19C14.21 6.04 13.09 6.7 11.95 6.61C11.8 5.46 12.36 4.26 13 3.5Z" fill="currentColor"/>
                </svg>
                <span>
                  <span className="block text-xs">Download on the</span>
                  <span className="block text-xl font-medium">App Store</span>
                </span>
              </a>
              <a 
                href="#" 
                className="inline-flex items-center justify-center bg-black text-white rounded-xl px-6 py-3 hover:bg-gray-800 transition-colors"
              >
                <svg className="w-6 h-6 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M3 20.5V3.5C3 2.91 3.34 2.39 3.84 2.15L13.69 12L3.84 21.85C3.34 21.6 3 21.09 3 20.5ZM16.81 15.12L6.05 21.34L14.54 12.85L16.81 15.12ZM20.16 10.81C20.5 11.08 20.75 11.5 20.75 12C20.75 12.5 20.53 12.9 20.18 13.18L17.89 14.5L15.39 12L17.89 9.5L20.16 10.81ZM6.05 2.66L16.81 8.88L14.54 11.15L6.05 2.66Z" fill="currentColor"/>
                </svg>
                <span>
                  <span className="block text-xs">GET IT ON</span>
                  <span className="block text-xl font-medium">Google Play</span>
                </span>
              </a>
            </div>
          </div>

          <div 
            ref={phoneRef}
            className="relative flex justify-center transition-all duration-1000 opacity-0 translate-x-20"
          >
            <div className="relative w-64 h-auto">
              <div className="absolute inset-0 bg-gradient-to-br from-green-300 to-blue-300 opacity-50 rounded-[3rem] blur-2xl"></div>
              <div className="relative border-8 border-black rounded-[3rem] overflow-hidden shadow-2xl">
                <div className="aspect-[9/19.5] bg-black">
                  <img 
                    src="https://images.pexels.com/photos/5025669/pexels-photo-5025669.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                    alt="EarthWeels mobile app" 
                    className="w-full h-full object-cover opacity-80"
                  />
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center p-6">
                    <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mb-3">
                      <Smartphone size={30} className="text-white" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">EarthWeels</h3>
                    <p className="text-sm opacity-80">Ride smarter with our premium eco-friendly taxi service</p>
                    <div className="mt-6 bg-white bg-opacity-20 rounded-lg px-4 py-2">
                      <p className="text-xs font-medium">Book your ride in seconds</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AppPromotion;