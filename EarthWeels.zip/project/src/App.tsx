import React from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import HowItWorks from './components/HowItWorks';
import FleetSection from './components/FleetSection';
import BenefitsSection from './components/BenefitsSection';
import TestimonialsSection from './components/TestimonialsSection';
import AppPromotion from './components/AppPromotion';
import CtaSection from './components/CtaSection';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white text-gray-900">
      <Header />
      <main>
        <HeroSection />
        <HowItWorks />
        <FleetSection />
        <BenefitsSection />
        <TestimonialsSection />
        <AppPromotion />
        <CtaSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;